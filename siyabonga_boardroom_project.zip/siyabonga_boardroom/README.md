# Siyabonga Technology Interactive Boardroom

This project is a runnable Python CLI boardroom for **Siyabonga Technology**. You, as CEO, can speak to Steve, Tawanda, Lucia, or all three. Each executive sees the shared transcript and retrieves only the real sources configured for that executive.

> This package does not contain mock financials, fake CRM records, fabricated marketing metrics, or placeholder search results. If a source is not configured or cannot be reached, the relevant executive must disclose that limitation.

## Files

| File | Purpose |
|---|---|
| `boardroom.py` | Interactive conversation, shared memory, LLM calls, transcript logging, and controls. |
| `data_sources.py` | Real Excel and JSON REST connectors. |
| `config.py` | Environment-based configuration. |
| `.env.example` | Configuration template; copy it to `.env`. |
| `requirements.txt` | Python dependencies. |
| `logs/` | Append-only JSONL transcript and saved snapshots. |
| `data/` | Place approved local business files here if desired. |

## Installation

Use Python 3.10 or newer. From this directory, create a virtual environment and install dependencies:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Edit `.env` and provide a valid `OPENAI_API_KEY`. Set `OPENAI_API_BASE` only when using an OpenAI-compatible provider endpoint. Set `LLM_MODEL` to a model available from your chosen provider. The default is `gpt-5.5` for the Manus-compatible catalog used while preparing this prototype; verify availability in your own account before production use.

Start the boardroom with:

```bash
python boardroom.py
```

## Real data configuration

### Steve: Excel finance source

Set `FINANCE_EXCEL_PATH` to an existing workbook that your finance team approves for AI-assisted analysis. Steve reads the first worksheet by default, or the worksheet named by `FINANCE_SHEET_NAME`. The application sends a bounded table snapshot to the model; it does not write to or modify the workbook.

```dotenv
FINANCE_EXCEL_PATH=/absolute/path/to/siyabonga_financials.xlsx
FINANCE_SHEET_NAME=Current Month
```

### Tawanda: CRM and business-development source

Set `CRM_API_URL` to a read-only endpoint that returns JSON and `CRM_API_TOKEN` to its bearer token. The current connector intentionally uses a generic REST contract because the exact CRM has not yet been specified. The endpoint should expose only the fields Tawanda is authorized to see, such as pipeline stage, expected close date, account segment, and opportunity value.

```dotenv
CRM_API_URL=https://your-crm.example.com/api/boardroom/pipeline
CRM_API_TOKEN=your_read_only_token
```

### Lucia: marketing and analytics source

Set `MARKETING_API_URL` to a read-only JSON endpoint prepared from your approved marketing or analytics platform. For example, your integration layer may expose campaign spend, leads, conversion rate, customer acquisition cost, and attributed revenue.

```dotenv
MARKETING_API_URL=https://your-analytics.example.com/api/boardroom/marketing
MARKETING_API_TOKEN=your_read_only_token
```

### Optional real search source

If you have a search provider or internal market-intelligence service with a JSON endpoint, set `SEARCH_API_URL`. The application sends the current agenda text as the `q` query parameter and sends the token as a bearer token. If it is not configured, the executives must not claim that they searched the web.

```dotenv
SEARCH_API_URL=https://your-search-service.example.com/search
SEARCH_API_TOKEN=your_search_token
```

## Conversation commands

After typing a CEO message, choose `STEVE`, `TAWANDA`, `LUCIA`, or `ALL`. `HISTORY` prints the shared transcript, `SAVE` writes a text snapshot, `HELP` prints the commands, and `EXIT` ends the meeting. Every utterance is also appended to `logs/boardroom.jsonl`.

## Production controls before connecting sensitive systems

Use read-only credentials and separate service accounts for each data source. Limit the fields returned by each endpoint instead of giving the model unrestricted database access. Keep API tokens only in environment variables or a secret manager, never in the workbook or source code. Review transcript retention, access control, and data-protection requirements before placing customer, employee, financial, or personal information into the system. The boardroom produces recommendations; a human must approve payments, customer communications, record changes, and other consequential actions.

## Important integration limitation

The project is complete and runnable, but no private business system can be connected until you provide the actual source details. In particular, the generic CRM and marketing URLs must be replaced with endpoints from your selected platforms, and the Excel path must point to your real workbook. The code deliberately does not pretend those systems are connected.
